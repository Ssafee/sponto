@extends('layouts.app')
@section('content')



<section class="banner-section banner-style-three p_relative">
    <div class="pattern-layer" style="background-image: url(assets/images/shape/shape-10.png);"></div>
    <div class="shape">
        <div class="shape-1" style="background-image: url(assets/images/shape/shape-11.png);"></div>
        <div class="shape-2" style="background-image: url(assets/images/shape/shape-12.png);"></div>
        <div class="shape-3" style="background-image: url(assets/images/shape/shape-13.png);"></div>
    </div>
    <div class="auto-container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                <div class="content-box">
                    <h2>Finding Solutions to Staffing Challenges <span>Sponto</span></h2>
                    <p>It's all about placing the right talent with the right tools, backed by a dedicated support team that ensures a seamless, efficient, and results-driven hiring process.</p>
                    <div class="btn-box">
                        <a href="https://calendly.com/sponto-pk" class="theme-btn btn-one mr_20"><span>Book a Call</span></a>
                        
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                <div class="image-inner">
                    <div class="icon-logo"><img src="assets/images/icons/logo-icon-1.png" alt=""></div>
                    <div class="image-box mr_15">
                        <figure class="image image-1 mb_15"><img src="assets/images/banner/banner-img-1.jpg" alt=""></figure>
                        <figure class="image image-2"><img src="assets/images/banner/banner-img-2.jpg" alt=""></figure>
                    </div>
                    <div class="image-box pt_55">
                        <figure class="image image-3 mb_15"><img src="assets/images/banner/banner-img-3.jpg" alt=""></figure>
                        <figure class="image image-4"><img src="assets/images/banner/banner-img-4.jpg" alt=""></figure>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="slide-text">
    <div class="text-inner">
        <ul class="text-list">
            <li>Warehouse</li>
            <li>Hospitality</li>
            <li>Manufacturing</li>
            <li>Special Events</li>
            <li>General Labor</li>
            <li>Warehouse</li>
            <li>Hospitality</li>
            <li>Manufacturing</li>
            <li>Special Events</li>
            <li>General Labor</li>
            <li>Warehouse</li>
            <li>Hospitality</li>
            <li>Manufacturing</li>
            <li>Special Events</li>
            <li>General Labor</li>
            <li>Warehouse</li>
            <li>Hospitality</li>
            <li>Manufacturing</li>
            <li>Special Events</li>
            <li>General Labor</li>
            <li>Warehouse</li>
            <li>Hospitality</li>
            <li>Manufacturing</li>
            <li>Special Events</li>
            <li>General Labor</li>
            <li>Warehouse</li>
            <li>Hospitality</li>
            <li>Manufacturing</li>
            <li>Special Events</li>
            <li>General Labor</li>
            <li>Warehouse</li>
            <li>Hospitality</li>
            <li>Manufacturing</li>
            <li>Special Events</li>
            <li>General Labor</li>
            <li>Warehouse</li>
            <li>Hospitality</li>
            <li>Manufacturing</li>
            <li>Special Events</li>
            <li>General Labor</li>
            <li>Warehouse</li>
            <li>Hospitality</li>
            <li>Manufacturing</li>
            <li>Special Events</li>
            <li>General Labor</li>
            <li>Warehouse</li>
            <li>Hospitality</li>
            <li>Manufacturing</li>
            <li>Special Events</li>
            <li>General Labor</li>
        </ul>
    </div>
</div>

<br>
<br>
<br>

<section class="process-section pt_120 pb_90">
    <div class="pattern-layer" style="background-image: url(assets/images/shape/shape-3.png);"></div>
    <div class="auto-container">
        <div class="sec-title light centred pb_60 sec-title-animation animation-style2">
            <span class="sub-title mb_10 title-animation">SOLUTIONS WE PROVIDE</span>
            <h2 class="title-animation">Inovetive Solutions For Talents</h2>
            <p>We never tie our clients in contracts. We make it easier for them to do the business and make it fun with our secret referral plans</p>
        </div>
        <div class="tabs-box">
            <ul class="tab-btns tab-buttons">
                <li class="tab-btn active-btn" data-tab="#tab-1"><i class="far fa-user"></i>For Talents</li>
                <li class="tab-btn" data-tab="#tab-2"><i class="far fa-briefcase"></i>For Business</li>
            </ul>
            <div class="tabs-content">
                <div class="tab active-tab" id="tab-1">
                    <div class="row clearfix">
                        <div class="col-lg-3 col-md-6 col-sm-12 processing-block">
                            <div class="processing-block-one">
                                <div class="inner-box">
                                    <span class="count-text">1</span>
                                    <h3><a href="index.html">Temporary Staffing</a></h3>
                                    <p>The wise man therefore always holds in these matters to this by...</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 processing-block">
                            <div class="processing-block-one">
                                <div class="inner-box">
                                    <span class="count-text">2</span>
                                    <h3><a href="index.html">Contracts Staffing</a></h3>
                                    <p>Right to find fault with a man choses these matters to this...</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 processing-block">
                            <div class="processing-block-one">
                                <div class="inner-box">
                                    <span class="count-text">3</span>
                                    <h3><a href="index.html">Project Based Hiring </a></h3>
                                    <p>Occasionally occur in these matters to this by the readable content...</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 processing-block">
                            <div class="processing-block-one">
                                <div class="inner-box">
                                    <span class="count-text">4</span>
                                    <h3><a href="index.html">Permanent Staffings</a></h3>
                                    <p>The wise man therefore always holds in this matters to this by... </p>
                                </div>
                            </div>
                        </div>  
                    </div>
                </div>
                <div class="tab" id="tab-2">
                    <div class="row clearfix">
                        <div class="col-lg-4 col-md-6 col-sm-12 processing-block">
                            <div class="processing-block-one">
                                <div class="inner-box">
                                    <span class="count-text">1</span>
                                    <h3><a href="index.html">Sign up, It's Free!</a></h3>
                                    <p>Our team will set up your account and help you build job to easy-to-use web dashboard.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 processing-block">
                            <div class="processing-block-one">
                                <div class="inner-box">
                                    <span class="count-text">2</span>
                                    <h3><a href="index.html">Post jobs in minutes</a></h3>
                                    <p>Create and post anywhere from 1-100 job openings with just a few clicks. customize your own.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 processing-block">
                            <div class="processing-block-one">
                                <div class="inner-box">
                                    <span class="count-text">3</span>
                                    <h3><a href="index.html">Review Your Staff</a></h3>
                                    <p>View bios, reviews, and rosters before workers arrive on the job, and post reviews and pay, effortlessly.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<br>
<br>
<br>
<br>
<br>


<!-- clients-section -->
        <section class="clients-section">
            <div class="auto-container">
                <div class="inner-container">
                    <div class="clients-box">
                        <figure class="clients-logo"><a href="index.html"><img src="{{asset('assets/images/brandLogo/1.png')}}" alt=""></a></figure>
                        <figure class="overlay-logo"><a href="index.html"><img src="{{asset('assets/images/brandLogo/1.png')}}" alt=""></a></figure>
                    </div>
                    <div class="clients-box">
                        <figure class="clients-logo"><a href="index.html"><img src="{{asset('assets/images/brandLogo/2.png')}}" alt=""></a></figure>
                        <figure class="overlay-logo"><a href="index.html"><img src="{{asset('assets/images/brandLogo/2.png')}}" alt=""></a></figure>
                    </div>
                    <div class="clients-box">
                        <figure class="clients-logo"><a href="index.html"><img src="{{asset('assets/images/brandLogo/3.png')}}" alt=""></a></figure>
                        <figure class="overlay-logo"><a href="index.html"><img src="{{asset('assets/images/brandLogo/3.png')}}" alt=""></a></figure>
                    </div>
                    <div class="clients-box">
                        <figure class="clients-logo"><a href="index.html"><img src="{{asset('assets/images/brandLogo/4.png')}}" alt=""></a></figure>
                        <figure class="overlay-logo"><a href="index.html"><img src="{{asset('assets/images/brandLogo/4.png')}}" alt=""></a></figure>
                    </div>
                    <div class="clients-box">
                        <figure class="clients-logo"><a href="index.html"><img src="{{asset('assets/images/brandLogo/5.png')}}" alt=""></a></figure>
                        <figure class="overlay-logo"><a href="index.html"><img src="{{asset('assets/images/brandLogo/5.png')}}" alt=""></a></figure>
                    </div>
                </div>
            </div>
        </section>
        <!-- clients-section end -->

<!-- chooseus-section -->
<section class="chooseus-section pt_200 pb_90">
    <div class="pattern-layer" style="background-image: url(assets/images/shape/shape-2.png);"></div>
    <div class="auto-container">
        <div class="sec-title centred pb_60 sec-title-animation animation-style2">
            <span class="sub-title mb_10 title-animation">How Its Possible</span>
            <h2 class="title-animation">Simple Staffing Procedures</h2>
            <p>Long Established fact that a reader will be distracted by the readable content of a page</p>
        </div>
        <div class="inner-container">
            <div class="row clearfix">
                <div class="col-lg-4 col-md-6 col-sm-12 chooseus-block">
                    <div class="chooseus-block-one">
                        <div class="inner-box">
                            <div class="icon-box"><i class="icon-4"></i></div>
                            <h3><a href="index.html">Discovery & Job Analysis</a></h3>
                            <p>In a 15-30 minute consultation, we discuss your hiring needs, ideal roles ensuring you get the right talent at the best value.</p>
                            <div class="link"><a href="index.html">Learn More<i class="icon-7"></i></a></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 chooseus-block">
                    <div class="chooseus-block-one">
                        <div class="inner-box">
                            <div class="icon-box"><i class="icon-5"></i></div>
                            <h3><a href="index.html">Shortlistng & Interviews</a></h3>
                            <p>We thoroughly vet candidates from our pre-screened talent pool, ensuring you get the perfect fit for your team.</p>
                            <div class="link"><a href="index.html">Learn More<i class="icon-7"></i></a></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 chooseus-block">
                    <div class="chooseus-block-one">
                        <div class="inner-box">
                            <div class="icon-box"><i class="icon-6"></i></div>
                            <h3><a href="index.html">Job Place & Check</a></h3>
                                <p>Interview the top 5 candidates, hire when ready—risk-free with time tracking and free replacements.</p>
                            <div class="link"><a href="index.html">Learn More<i class="icon-7"></i></a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- chooseus-section end -->

<div class="slide-text">
    <div class="text-inner">
        <ul class="text-list">
            <li>Warehouse</li>
            <li>Hospitality</li>
            <li>Manufacturing</li>
            <li>Special Events</li>
            <li>General Labor</li>
            <li>Warehouse</li>
            <li>Hospitality</li>
            <li>Manufacturing</li>
            <li>Special Events</li>
            <li>General Labor</li>
            <li>Warehouse</li>
            <li>Hospitality</li>
            <li>Manufacturing</li>
            <li>Special Events</li>
            <li>General Labor</li>
            <li>Warehouse</li>
            <li>Hospitality</li>
            <li>Manufacturing</li>
            <li>Special Events</li>
            <li>General Labor</li>
            <li>Warehouse</li>
            <li>Hospitality</li>
            <li>Manufacturing</li>
            <li>Special Events</li>
            <li>General Labor</li>
            <li>Warehouse</li>
            <li>Hospitality</li>
            <li>Manufacturing</li>
            <li>Special Events</li>
            <li>General Labor</li>
            <li>Warehouse</li>
            <li>Hospitality</li>
            <li>Manufacturing</li>
            <li>Special Events</li>
            <li>General Labor</li>
            <li>Warehouse</li>
            <li>Hospitality</li>
            <li>Manufacturing</li>
            <li>Special Events</li>
            <li>General Labor</li>
            <li>Warehouse</li>
            <li>Hospitality</li>
            <li>Manufacturing</li>
            <li>Special Events</li>
            <li>General Labor</li>
            <li>Warehouse</li>
            <li>Hospitality</li>
            <li>Manufacturing</li>
            <li>Special Events</li>
            <li>General Labor</li>
        </ul>
    </div>
</div>

<br>
<br>
<br>

<!-- industries-section -->
<section class="industries-section pt_20 pb_120">
    <div class="auto-container">
        <div class="sec-title centred pb_60 sec-title-animation animation-style2">
            <span class="sub-title mb_10 title-animation">Industries</span>
            <h2 class="title-animation">Industries Served</h2>
        </div>
        <div class="inner-container clearfix">
            <div class="industries-block-one">
                <div class="inner-box">
                    <div class="icon-box"><img src="{{asset('assets\images\icon\1.png')}}" alt=""></div>
                    <h3><a href="index.html">Hotel</a></h3>
                    <p>2853 Staffs</p>
                </div>
            </div>
            <div class="industries-block-one">
                <div class="inner-box">
                    <div class="icon-box"><img src="{{asset('assets\images\icon\2.png')}}" alt=""></div>
                    <h3><a href="index.html">Hospitality</a></h3>
                    <p>2256 Staffs</p>
                </div>
            </div>
            <div class="industries-block-one">
                <div class="inner-box">
                    <div class="icon-box"><img src="{{asset('assets\images\icon\3.png')}}" alt=""></div>
                    <h3><a href="index.html">Kitchen</a></h3>
                    <p>1408 Staffs</p>
                </div>
            </div>
            <div class="industries-block-one">
                <div class="inner-box">
                    <div class="icon-box"><img src="{{asset('assets\images\icon\4.png')}}" alt=""></div>
                    <h3><a href="index.html">Retail</a></h3>
                    <p>1740 Staffs</p>
                </div>
            </div>
            <div class="industries-block-one">
                <div class="inner-box">
                    <div class="icon-box"><img src="{{asset('assets\images\icon\5.png')}}" alt=""></div>
                    <h3><a href="index.html">Special Events</a></h3>
                    <p>3948 Staffs</p>
                </div>
            </div>
            <div class="industries-block-one">
                <div class="inner-box">
                    <div class="icon-box"><img src="{{asset('assets\images\icon\6.png')}}" alt=""></div>
                    <h3><a href="index.html">General Labor</a></h3>
                    <p>2984 Staffs</p>
                </div>
            </div>
            <div class="industries-block-one">
                <div class="inner-box">
                    <div class="icon-box"><img src="{{asset('assets\images\icon\7.png')}}" alt=""></div>
                    <h3><a href="index.html">Driving</a></h3>
                    <p>4509 Staffs</p>
                </div>
            </div>
            <div class="industries-block-one">
                <div class="inner-box">
                    <div class="icon-box"><img src="{{asset('assets\images\icon\8.png')}}" alt=""></div>
                    <h3><a href="index.html">Senior Living</a></h3>
                    <p>1039 Staffs</p>
                </div>
            </div>
        </div>

    </div>
</section>
<!-- industries-section end -->


<section class="funfact-section alternat-2 centred pb_90">
    <div class="auto-container">
        <div class="row clearfix">
            <div class="col-lg-3 col-md-6 col-sm-12 funfact-block">
                <div class="funfact-block-one">
                    <div class="inner-box">
                        <div class="count-outer">
                            <span class="odometer" data-count="70">00</span><span class="symble">+</span>
                        </div>
                        <p>Employees Hired In Last Year</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 funfact-block">
                <div class="funfact-block-one">
                    <div class="inner-box">
                        <div class="count-outer">
                            <span class="odometer" data-count="13">00</span>
                        </div>
                        <p>Employers Formed in Last Year</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 funfact-block">
                <div class="funfact-block-one">
                    <div class="inner-box">
                        <div class="count-outer">
                            <span class="odometer" data-count="30">00</span><span class="symble">k+</span>
                        </div>
                        <p>Vetted talent pool 30,000+ available</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 funfact-block">
                <div class="funfact-block-one">
                    <div class="inner-box">
                        <div class="count-outer">
                            <span class="odometer" data-count="97">00</span><span class="symble">%</span>
                        </div>
                        <p>Client Successful Rate.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="industries-style-three centred pt_120 pb_120">
    <div class="pattern-layer" style="background-image: url(assets/images/shape/shape-15.png);"></div>
    <div class="auto-container">
        <div class="sec-title light pb_60 sec-title-animation animation-style2">
            <span class="sub-title mb_10 title-animation">Industries</span>
            <h2 class="title-animation">Industries Served</h2>
        </div>
        <div class="row clearfix">
            <div class="col-lg-3 col-md-6 col-sm-12 industries-block">
                <div class="industries-block-three">
                    <div class="inner-box">
                        <div class="icon-box"><img src="{{asset('assets\images\icon\1.png')}}" alt=""></div>
                        <h3><a href="index.html">Hotel</a></h3>
                        <p>2853 Staffs</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 industries-block">
                <div class="industries-block-three">
                    <div class="inner-box">
                        <div class="icon-box"><img src="{{asset('assets\images\icon\2.png')}}" alt=""></div>
                        <h3><a href="index.html">Hospitality</a></h3>
                        <p>2256 Staffs</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 industries-block">
                <div class="industries-block-three">
                    <div class="inner-box">
                        <div class="icon-box"><img src="{{asset('assets\images\icon\3.png')}}" alt=""></div>
                        <h3><a href="index.html">Kitchen</a></h3>
                        <p>1408 Staffs</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 industries-block">
                <div class="industries-block-three">
                    <div class="inner-box">
                        <div class="icon-box"><img src="{{asset('assets\images\icon\4.png')}}" alt=""></div>
                        <h3><a href="index.html">Retail</a></h3>
                        <p>1740 Staffs</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 industries-block">
                <div class="industries-block-three">
                    <div class="inner-box">
                        <div class="icon-box"><img src="{{asset('assets\images\icon\5.png')}}" alt=""></div>
                        <h3><a href="index.html">Events</a></h3>
                        <p>3948 Staffs</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 industries-block">
                <div class="industries-block-three">
                    <div class="inner-box">
                        <div class="icon-box"><img src="{{asset('assets\images\icon\6.png')}}" alt=""></div>
                        <h3><a href="index.html">Labor</a></h3>
                        <p>2984 Staffs</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 industries-block">
                <div class="industries-block-three">
                    <div class="inner-box">
                        <div class="icon-box"><img src="{{asset('assets\images\icon\7.png')}}" alt=""></div>
                        <h3><a href="index.html">Driving</a></h3>
                        <p>4509 Staffs</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 industries-block">
                <div class="industries-block-three">
                    <div class="inner-box">
                        <div class="icon-box"><img src="{{asset('assets\images\icon\8.png')}}" alt=""></div>
                        <h3><a href="index.html">Caretaker</a></h3>
                        <p>1039 Staffs</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="more-btn"><a href="index-3.html" class="theme-btn btn-one">View All Categories</a></div>
    </div>
</section>

<br>
<!-- dueal-section -->
<section class="dueal-section alternat-3 p_relative pl_100 pr_100">
    <div class="outer-container p_relative pt_120 pb_120">
        <div class="bg-color"></div>
        <div class="shape">
            <div class="shape-1"></div>
            <div class="shape-2"></div>
            <div class="shape-3"></div>
            <div class="shape-4"></div>
        </div>
        <div class="auto-container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                    <div class="content_block_three">
                        <div class="content-box">
                            <div class="sec-title pb_30 sec-title-animation animation-style2">
                                <span class="sub-title mb_10 title-animation">General Faqs</span>
                                <h2 class="title-animation">Frequently Asked Questions</h2>
                            </div>
                            <ul class="accordion-box">
                                <li class="accordion block active-block">
                                    <div class="acc-btn active">
                                        <div class="icon-box"><i class="icon-21"></i></div>
                                        <h4>How Can I Prepare for an Interview?</h4>
                                    </div>
                                    <div class="acc-content current">
                                        <div class="content">
                                            <p>To prepare for an interview, research the company, understand the job role and responsibilities, and prepare questions to ask the interviewer.</p>
                                        </div>
                                    </div>
                                </li>
                                <li class="accordion block">
                                    <div class="acc-btn">
                                        <div class="icon-box"><i class="icon-21"></i></div>
                                        <h4>Hiring Managers and Candidates?</h4>
                                    </div>
                                    <div class="acc-content">
                                        <div class="content">
                                            <p>To prepare for an interview, research the company, understand the job role and responsibilities, and prepare questions to ask the interviewer.</p>
                                        </div>
                                    </div>
                                </li>
                                <li class="accordion block">
                                    <div class="acc-btn">
                                        <div class="icon-box"><i class="icon-21"></i></div>
                                        <h4>Clarifying Recruitment Concepts?</h4>
                                    </div>
                                    <div class="acc-content">
                                        <div class="content">
                                            <p>To prepare for an interview, research the company, understand the job role and responsibilities, and prepare questions to ask the interviewer.</p>
                                        </div>
                                    </div>
                                </li>
                                <li class="accordion block">
                                    <div class="acc-btn">
                                        <div class="icon-box"><i class="icon-21"></i></div>
                                        <h4>Employers look for in candidates?</h4>
                                    </div>
                                    <div class="acc-content">
                                        <div class="content">
                                            <p>To prepare for an interview, research the company, understand the job role and responsibilities, and prepare questions to ask the interviewer.</p>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                    <div class="testimonial-content ml_130">
                        <div class="single-item-carousel owl-carousel owl-theme owl-nav-none dots-style-one">
                            <div class="testimonial-block-three">
                                <div class="inner-box">
                                    <div class="icon-box"><i class="icon-36"></i></div>
                                    <h2>Company and was impressed by the personalized approach of their recruitment team. They kept me informed at every stage</h2>
                                    <figure class="signature mb_30"><img src="assets/images/icons/signature-1.png" alt=""></figure>
                                    <div class="author-box">
                                        <figure class="author-thumb"><img src="assets/images/resource/testimonial-4.png" alt=""></figure>
                                        <h3>Franklin Bailey</h3>
                                        <span class="designation">CEO, JobAway</span>
                                    </div>
                                </div>
                            </div>
                            <div class="testimonial-block-three">
                                <div class="inner-box">
                                    <div class="icon-box"><i class="icon-36"></i></div>
                                    <h2>Company and was impressed by the personalized approach of their recruitment team. They kept me informed at every stage</h2>
                                    <figure class="signature mb_30"><img src="assets/images/icons/signature-1.png" alt=""></figure>
                                    <div class="author-box">
                                        <figure class="author-thumb"><img src="assets/images/resource/testimonial-4.png" alt=""></figure>
                                        <h3>Franklin Bailey</h3>
                                        <span class="designation">CEO, JobAway</span>
                                    </div>
                                </div>
                            </div>
                            <div class="testimonial-block-three">
                                <div class="inner-box">
                                    <div class="icon-box"><i class="icon-36"></i></div>
                                    <h2>Company and was impressed by the personalized approach of their recruitment team. They kept me informed at every stage</h2>
                                    <figure class="signature mb_30"><img src="assets/images/icons/signature-1.png" alt=""></figure>
                                    <div class="author-box">
                                        <figure class="author-thumb"><img src="assets/images/resource/testimonial-4.png" alt=""></figure>
                                        <h3>Franklin Bailey</h3>
                                        <span class="designation">CEO, JobAway</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- dueal-section end -->

@endsection